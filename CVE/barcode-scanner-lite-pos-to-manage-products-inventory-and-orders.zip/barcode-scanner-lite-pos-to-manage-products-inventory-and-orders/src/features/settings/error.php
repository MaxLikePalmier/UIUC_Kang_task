<div id="bs-settings-page">
    <h2><?php echo $title; ?></h2>
    <div>
        <?php echo $error['message']; ?>
    </div>
</div>