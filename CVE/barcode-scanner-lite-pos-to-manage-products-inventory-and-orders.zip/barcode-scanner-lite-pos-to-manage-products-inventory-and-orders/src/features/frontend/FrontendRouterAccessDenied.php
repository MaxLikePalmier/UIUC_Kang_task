<?php

?>
<title>Barcode Scanner with Inventory & Order Manager - (business)</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<div style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100%;"><?php echo esc_html__("You don't have access to this page.", "us-barcode-scanner"); ?></div>