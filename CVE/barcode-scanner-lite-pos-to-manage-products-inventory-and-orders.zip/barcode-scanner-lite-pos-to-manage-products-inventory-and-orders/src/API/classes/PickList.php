<?php

namespace UkrSolution\BarcodeScanner\API\classes;

class PickList
{
    public static function getTemplate($post, $order, $settings)
    {
        return '';



    }
}
