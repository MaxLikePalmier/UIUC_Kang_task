<?php

namespace UkrSolution\BarcodeScanner\API\routes;

use UkrSolution\BarcodeScanner\API\Routes;

class Post extends Routes
{
    public function __construct()
    {


    }
}
